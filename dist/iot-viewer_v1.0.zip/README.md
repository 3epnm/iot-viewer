IoT-viewer
==========

**A graphical viewer for Internet-of-Things services**

The IoT Viewer is a fully in JavaScript developed application. All user data will be saved to the localStorage of the browser or device. In the development special attention was paid to the usability of touch devices. The release version of the iot-viewer also supports ApplicationCache, and can therefore be started and used, apart from the access to the cloud service of the provider itself, without server-access.

For more informations, visit [http://mb.aquarius.uberspace.de/internet-of-things-viewer/](http://mb.aquarius.uberspace.de/internet-of-things-viewer/) or open the demo
[http://mb.aquarius.uberspace.de/iot-viewer/](http://mb.aquarius.uberspace.de/iot-viewer/), which covers a Introduction.
